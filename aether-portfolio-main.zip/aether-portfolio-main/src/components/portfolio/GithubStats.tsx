"use client";
import { Section } from "./Section";
import { motion } from "framer-motion";
import { GitBranch, GitCommit, Star, Activity } from "lucide-react";
import { profile } from "@/lib/portfolio-data";
import { TiltCard } from "./TiltCard";

const items = [
  { label: "Public Repos", value: "20+", Icon: GitBranch },
  { label: "Commits this year", value: "850+", Icon: GitCommit },
  { label: "Stars earned", value: "40+", Icon: Star },
  { label: "Streak", value: "Active", Icon: Activity },
];

export function GithubStats() {
  return (
    <Section
      id="github"
      eyebrow="// 07 — activity"
      title="GitHub Stats"
      subtitle={`Open source playground · @${profile.githubHandle}`}
    >
      <div className="grid gap-5 md:grid-cols-4">
        {items.map((it, i) => (
          <TiltCard key={it.label} className="group h-full">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="glass-strong relative overflow-hidden rounded-2xl p-6"
            >
              <it.Icon className="text-accent" size={20} />
              <div className="mt-4 font-display text-4xl text-gradient">{it.value}</div>
              <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                {it.label}
              </div>
              <div className="pointer-events-none absolute -bottom-8 -right-8 h-24 w-24 rounded-full bg-primary/30 blur-3xl transition group-hover:bg-accent/30" />
            </motion.div>
          </TiltCard>
        ))}
      </div>

      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <a
          href={profile.github}
          target="_blank"
          rel="noreferrer"
          data-cursor="hover"
          className="glass group relative block overflow-hidden rounded-2xl"
        >
          <img
            src={`https://github-readme-stats.vercel.app/api?username=${profile.githubHandle}&show_icons=true&hide_border=true&bg_color=0D0719&title_color=D4A24A&icon_color=A855F7&text_color=ffffff`}
            alt="GitHub stats"
            loading="lazy"
            className="w-full transition group-hover:scale-[1.02]"
          />
        </a>
        <a
          href={profile.github}
          target="_blank"
          rel="noreferrer"
          data-cursor="hover"
          className="glass group relative block overflow-hidden rounded-2xl"
        >
          <img
            src={`https://github-readme-stats.vercel.app/api/top-langs/?username=${profile.githubHandle}&layout=compact&hide_border=true&bg_color=0D0719&title_color=D4A24A&text_color=ffffff`}
            alt="Top languages"
            loading="lazy"
            className="w-full transition group-hover:scale-[1.02]"
          />
        </a>
      </div>
    </Section>
  );
}
